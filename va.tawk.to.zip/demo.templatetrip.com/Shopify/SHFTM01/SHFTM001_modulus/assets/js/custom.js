$(document).ready(function() {
    $("#goToTop").hide();
    $(function() {
        $(window).scroll(function() {
            if ($(this).scrollTop() > 150) {
                $(".goToTop").fadeIn();
            } else {
                $(".goToTop").fadeOut();
            }
        });
        $(".goToTop").click(function() {
            $("body,html").animate({
                scrollTop: 0
            }, 1000);
            return !1;
        });
    });
    var ttfeatureblock = $("#ttheader-carousel");
    ttfeatureblock.owlCarousel({
        autoPlay: !0,
        items: 2,
        itemsDesktop: [1200, 2],
        itemsDesktopSmall: [991, 2],
        itemsTablet: [767, 1],
        itemsMobile: [480, 1],
        pagination: !0,
        navigation: !1
    });
    var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent);
    if (!isMobile) {
        if ($(".parallex").length) {
            $(".parallex").sitManParallex({
                invert: !1
            })
        }
    } else {
        $(".parallex").sitManParallex({
            invert: !0
        })
    }
    var ttfeatureblocks = $("#ttfooter-carousel");
    ttfeatureblocks.owlCarousel({
        autoPlay: !0,
        items: 2,
        itemsDesktop: [1200, 2],
        itemsDesktopSmall: [991, 2],
        itemsTablet: [767, 1],
        itemsMobile: [480, 1],
        pagination: !0,
        navigation: !1
    });
    var ttblogblock = $("#ttblog-carousel");
    ttblogblock.owlCarousel({
        autoPlay: !0,
        items: 2,
        itemsDesktop: [1200, 2],
        itemsDesktopSmall: [991, 2],
        itemsTablet: [767, 1],
        itemsMobile: [480, 1],
        pagination: !0,
        navigation: !1
    });
    var producthover = $("#product-hover");
    producthover.owlCarousel({
        autoPlay: !0,
        items: 3,
        itemsDesktop: [1200, 3],
        itemsDesktopSmall: [991, 2],
        itemsTablet: [767, 3],
        itemsMobile: [480, 1],
        pagination: !0,
        navigation: !1
    });
    var ttpageblock = $("#pages-collection");
    ttpageblock.owlCarousel({
        autoPlay: !0,
        items: 3,
        itemsDesktop: [1200, 3],
        itemsDesktopSmall: [991, 1],
        itemsTablet: [767, 1],
        itemsMobile: [480, 1],
        pagination: !0,
        navigation: !1,
        afterAction: function(el) {
            this.$owlItems.removeClass("active");
            this.$owlItems.eq(this.currentItem + 1).addClass("active");
        },
    });
    var ttsinglepageblock = $("#ttsinglepage");
    ttsinglepageblock.owlCarousel({
        autoPlay: !0,
        items: 3,
        itemsDesktop: [1200, 3],
        itemsDesktopSmall: [991, 1],
        itemsTablet: [767, 1],
        itemsMobile: [480, 1],
        pagination: !0,
        navigation: !1,
        afterAction: function(el) {
            this.$owlItems.removeClass("active");
            this.$owlItems.eq(this.currentItem + 1).addClass("active");
        },
    });
    $(".theme-view .view-slider .privew-slider-content").slick({
        slidesToShow: 1,
        autoplay: !0,
        autoplaySpeed: 1500,
        speed: 1000,
        slidesToScroll: 1,
        arrows: !1,
        pauseOnHover: !1
    })
    var $container = $(".item.all-layout");
    if ($container.length > 0) {
        $container.imagesLoaded(function() {
            $container.masonry({
                itemSelector: ".theme-layout-col",
                columnWidth: ".theme-layout-col",
                percentPosition: !0
            })
        })
    }
    jQuery('.item.all-layout').each(function() {
        $container.imagesLoaded(function() {
            $container.masonry()
        })
    })
    $(".content-bottom #showcase").slick({
        slidesToShow: 1,
        autoplay: !0,
        slidesToScroll: 1,
        arrows: !0
    });
});

$('.scan-code').click(function(event) {
    $(this).parent().toggleClass('active');
    event.stopPropagation();
});
$(".scan-code").on("click", function(event) {
    event.stopPropagation();
});

$(".rbt-theme-dropdown").on("click", function() {
    $("body").toggleClass("open");
    $('.rbt-sidearea').toggleClass('rbt-active');
    $('.rbt-list-holder').toggleClass('show');
});

setTimeout(function() {
    $('.rbt-list-holder').addClass('show');
    $("body").addClass("open");
    $('.rbt-sidearea').addClass('rbt-active');
}, 5000);

function hb_animated_contents() {
    $(".hb-animate-element:in-viewport").each(function(i) {
        var $this = $(this);
        if (!$this.hasClass("hb-in-viewport")) {
            setTimeout(function() {
                $this.addClass("hb-in-viewport");
            }, 300 * i);
        }
    });
}
$("#myModal").modal('show');

$('.close').on('click', function() {
    $('.view-preview').hide();
});

$('.popUp').on('click', function() {
    var demo_url = $(this).closest('.theme-layout-col').attr('data-url');
    $('.view-preview .modal-button').attr('href', demo_url);
    $('.view-preview').show();
});
$(document).ready(function() {
        hb_animated_contents();
    }),
    $(window).scroll(function() {
        hb_animated_contents();
    }),
    $(window).load(function() {
        hb_animated_contents();
    }),
    function() {
        var t,
            e = function(t, e) {
                return function() {
                    return t.apply(e, arguments);
                };
            };
        (t = (function() {
            function t() {}
            return (
                (t.prototype.extend = function(t, e) {
                    var i, o;
                    for (i in t) null != (o = t[i]) && (e[i] = o);
                    return e;
                }),
                (t.prototype.isMobile = function(t) {
                    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(t);
                }),
                t
            );
        })()),
        (this.WOW = (function() {
            function i(t) {
                null == t && (t = {}),
                    (this.scrollCallback = e(this.scrollCallback, this)),
                    (this.scrollHandler = e(this.scrollHandler, this)),
                    (this.start = e(this.start, this)),
                    (this.scrolled = !0),
                    (this.config = this.util().extend(t, this.defaults));
            }
            return (
                (i.prototype.defaults = {
                    boxClass: "wow",
                    animateClass: "animated",
                    offset: 0,
                    mobile: !0
                }),
                (i.prototype.init = function() {
                    var t;
                    return (this.element = window.document.documentElement), "interactive" === (t = document.readyState) || "complete" === t ? this.start() : document.addEventListener("DOMContentLoaded", this.start);
                }),
                (i.prototype.start = function() {
                    var t, e, i, o;
                    if (((this.boxes = this.element.getElementsByClassName(this.config.boxClass)), this.boxes.length)) {
                        if (this.disabled()) return this.resetStyle();
                        for (e = 0, i = (o = this.boxes).length; e < i; e++)(t = o[e]), this.applyStyle(t, !0);
                        return window.addEventListener("scroll", this.scrollHandler, !1), window.addEventListener("resize", this.scrollHandler, !1), (this.interval = setInterval(this.scrollCallback, 50));
                    }
                }),
                (i.prototype.stop = function() {
                    if ((window.removeEventListener("scroll", this.scrollHandler, !1), window.removeEventListener("resize", this.scrollHandler, !1), null != this.interval)) return clearInterval(this.interval);
                }),
                (i.prototype.show = function(t) {
                    return this.applyStyle(t), (t.className = t.className + " " + this.config.animateClass);
                }),
                (i.prototype.applyStyle = function(t, e) {
                    var i, o, n;
                    return (o = t.getAttribute("data-wow-duration")), (i = t.getAttribute("data-wow-delay")), (n = t.getAttribute("data-wow-iteration")), t.setAttribute("style", this.customStyle(e, o, i, n));
                }),
                (i.prototype.resetStyle = function() {
                    var t, e, i, o, n;
                    for (n = [], e = 0, i = (o = this.boxes).length; e < i; e++)(t = o[e]), n.push(t.setAttribute("style", "visibility: visible;"));
                    return n;
                }),
                (i.prototype.customStyle = function(t, e, i, o) {
                    var n;
                    return (
                        (n = t ? "visibility: hidden; -webkit-animation-name: none; -moz-animation-name: none; animation-name: none;" : "visibility: visible;"),
                        e && (n += "-webkit-animation-duration: " + e + "; -moz-animation-duration: " + e + "; animation-duration: " + e + ";"),
                        i && (n += "-webkit-animation-delay: " + i + "; -moz-animation-delay: " + i + "; animation-delay: " + i + ";"),
                        o && (n += "-webkit-animation-iteration-count: " + o + "; -moz-animation-iteration-count: " + o + "; animation-iteration-count: " + o + ";"),
                        n
                    );
                }),
                (i.prototype.scrollHandler = function() {
                    return (this.scrolled = !0);
                }),
                (i.prototype.scrollCallback = function() {
                    var t;
                    if (
                        this.scrolled &&
                        ((this.scrolled = !1),
                            (this.boxes = function() {
                                var e, i, o, n;
                                for (n = [], e = 0, i = (o = this.boxes).length; e < i; e++)(t = o[e]) && (this.isVisible(t) ? this.show(t) : n.push(t));
                                return n;
                            }.call(this)), !this.boxes.length)
                    )
                        return this.stop();
                }),
                (i.prototype.offsetTop = function(t) {
                    var e;
                    for (e = t.offsetTop;
                        (t = t.offsetParent);) e += t.offsetTop;
                    return e;
                }),
                (i.prototype.isVisible = function(t) {
                    var e, i, o, n, s;
                    return (i = t.getAttribute("data-wow-offset") || this.config.offset), (n = (s = window.pageYOffset) + this.element.clientHeight - i), (e = (o = this.offsetTop(t)) + t.clientHeight), o <= n && e >= s;
                }),
                (i.prototype.util = function() {
                    return this._util || (this._util = new t());
                }),
                (i.prototype.disabled = function() {
                    return !this.config.mobile && this.util().isMobile(navigator.userAgent);
                }),
                i
            );
        })());
    }.call(this),
    (wow = new WOW({
        animateClass: "animated",
        offset: 100
    })),
    wow.init(),
    (window.onload = function() {
        let t = document.querySelector(".page");
        (elemsix = document.querySelector("#menu")),
        (elemsevan = document.querySelector("#menu2")),
        (elemeight = document.querySelector("#menu3")),
        t.addEventListener("mousemove", function(t) {
            var s = t.clientX - window.innerWidth / 2,
                a = t.clientY - window.innerHeight / 2;
            (elemsix.style.transform = "translateX(" + (5 + s / 150) + "%) translateY(" + (5 + a / 150) + "%)"),
            (elemsevan.style.transform = "translateX(-" + (5 + s / 150) + "%) translateY(-" + (5 + a / 150) + "%)"),
            (elemeight.style.transform = "translateX(-" + (5 + s / 200) + "%) translateY(" + (5 + a / 200) + "%)");
        });
    });

function headerImages() {
    $(".header-image")
        .find(".demos-wrapper > div")
        .each(function() {
            var $demo = $(this);
            var delay = $demo.data("delay");
            var speed = $demo.find("img").data("speed");
            TweenLite.fromTo($demo, 2.5, {
                autoAlpha: 0,
                x: 90
            }, {
                autoAlpha: 1,
                x: 0,
                ease: Power4.easeOut,
                delay: delay
            });
            $(window).on("scroll", function() {
                var scroll = $(window).scrollTop(),
                    transform = scroll * -speed;
                TweenLite.to($demo, 2.3, {
                    y: transform,
                    ease: Power2.easeInOut
                });
            });
        });
}
$(document).ready(function() {
    hb_animated_contents();
});
$(window).scroll(function() {
    hb_animated_contents();
});
$(window).load(function() {
    hb_animated_contents();
});
$(document).ready(function() {
    headerImages();
});
$(document).resize(function() {
    headerImages();
});